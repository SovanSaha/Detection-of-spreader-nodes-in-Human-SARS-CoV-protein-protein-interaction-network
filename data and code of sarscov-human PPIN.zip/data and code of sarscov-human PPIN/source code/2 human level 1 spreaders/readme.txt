1: First create a file containing only level 1 human proteins of sarscov which will be the input of 1.py.
2: Run 1.py (For computing spreadability index to identify spreader nodes of level 1 human proteins)
3: Run 2.py (to calculate beta threshold of the network human for SIS)
4: Place the output of 2.py in the infection rate of SIS model (3.py)
5: Run 3.py to compute the infection rate of nodes using SIS. 


Note: 

Modify names of the text files inside python files accordingly.

For comparison of spreadability index with other centrality measures like BC, CC, LAC and DC use cytoscape.  