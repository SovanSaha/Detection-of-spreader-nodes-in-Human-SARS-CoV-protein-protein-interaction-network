Input:

      1) file containing level 1 human spreaders of sarscov with spreadability index separated by tab
      2) file containing level 2 human spreaders of sarscov with spreadability index separated by tab

1: Run rank_cov_human.py for ranking spreader edges.