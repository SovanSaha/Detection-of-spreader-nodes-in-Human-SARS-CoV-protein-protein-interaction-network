Input:

      1) file containg sarscov spreaders with spreadability index separated by tab
      2) file containg human level 1 spreaders of sarscov with spreadability index separated by tab

1: Run rank_cov_human.py for ranking spreader edges.

Note: 

Modify names of the text files inside python files accordingly.