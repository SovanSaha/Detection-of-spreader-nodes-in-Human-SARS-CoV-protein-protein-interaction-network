# -*- coding: utf-8 -*-
"""
Created on Thu Mar 19 11:37:43 2020

@author: COD
"""

import operator
from collections import OrderedDict 
count=0

#rank_cov_nodes=[]
#rank_cov_values=[]

d1 = {}

with open('cov_rank.txt', 'r') as in_file:
    stripped = (line.strip() for line in in_file)
    for line in stripped:
        line1=line.split()
        #rank_cov_nodes.append(line1[0])
        #rank_cov_values.append(line1[1])
        keys = line1[0]
        values = line1[1]
        d1[keys] = values
        
#rank_human_nodes=[]
#rank_human_values=[]
        
print(d1)

d2 = {}

with open('human_rank.txt', 'r') as in_file:
    stripped = (line.strip() for line in in_file)
    for line in stripped:
        line1=line.split()
        #rank_human_nodes.append(line1[0])
        #rank_human_values.append(line1[1])
        keys = line1[0]
        values = line1[1]
        d2[keys] = values
        
f1=open('cov_cov_interactions.txt','r')

hld1=f1.readlines()

str1=[]

count1=0

for line1 in hld1:
    count1=count1+1
    if (count1!=1):
        line1=line1.strip('\n')
        brk1=line1.split()
        str1.append(brk1[0].strip())
        str1.append(brk1[1].strip())
        
str1=list(set(str1))
#str1=['ORF3A']

f2=open('cov_human_interactions.txt','r')
hld2=f2.readlines()

hmn=[]
count2=0

for line1 in str1:
    line1=line1.strip('\n')
    for line2 in hld2:
        count2=count2+1
        if(count2!=1):
            line2=line2.strip('\n')
            brk2=line2.split()
            s1=brk2[0].strip()
            s2=brk2[1].strip()
            if (line1==(s1) and s1 in d1.keys() and s2 in d2.keys()):
                hmn.append(s1+'|'+s2)
                
hmn=list(set(hmn))

print(hmn)

d3={}

for i in hmn:
    keys = i
    i=i.strip('\n')
    i=i.split('|')
    if i[0] in d1.keys():
        s1=float(d1.get(i[0]))
    if i[1] in d2.keys():
        s2=float(d2.get(i[1]))
    values = float((s1+s2)/2)
    d3[keys] = values 
    
    
ga2=open('final_ranking_cov_human_edges.txt','w')

sorted_d3 = OrderedDict(dict( sorted(d3.items(), key=operator.itemgetter(1),reverse=True)))

for nm2, vl2 in sorted_d3.items(): 
    ga2.writelines(nm2+"|"+str(vl2)+'\n') 
    
ga2.close()
        























