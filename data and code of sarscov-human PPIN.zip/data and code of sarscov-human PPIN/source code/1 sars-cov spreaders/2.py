# -*- coding: utf-8 -*-
"""
Created on Sun Jan 19 14:41:36 2020

@author: CSE9
"""

from statistics import mean

def square(list):
    return [i ** 2 for i in list]

edges=[]
nodes=[]
count=0
with open('cov_cov_interactions.txt', 'r') as in_file:
    stripped = (line.strip() for line in in_file)
    for line in stripped:
        line1=line.split()
        count=count+1
        if count!=1:
            nodes.append(line1[0])
            nodes.append(line1[1])
            edges.append((line1[0],line1[1])) 
            
up_nodes=list(set(nodes))
up_edges=list(set(edges))

d = {}
for i in up_nodes:
    keys = i
    values = '#FFA500'
    d[keys] = values
    
print(d)

keys=[]
color_map=[]
for key in d:
    keys.append(key)
    color_map.append(d[key])
    
print(keys)
print(color_map)


import networkx as nx
G=nx.Graph()

# add nodes and edges (color can be html color name or hex code)
for key in d:
    G.add_node(str(key),color=str(d[key]))

G.add_edges_from(up_edges)

print(list(G.degree(up_nodes)))

degrees1 = [val for (node, val) in G.degree()]

#print(degrees1)
#print(mean(degrees1))

degrees2=square(degrees1)

#print(degrees2)
#print(mean(degrees2))

print(mean(degrees1)/mean(degrees2))#0.0045



