# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 13:52:11 2019

@author: CSE9
"""

import numpy.random as rnd
from collections import OrderedDict 
import operator
import networkx as nx

    
def SIS(G,k,infctd_prtn,pInfect, pRecover,itera):
    
    SPREADING_SUSCEPTIBLE = 'S'
    SPREADING_INFECTED = 'I'
    #SPREADING_INFECTED_SUSCEPTIBLE = 'IS'


    def spreading_init2( g ):
        """Initialise all node in the graph to be susceptible."""
        for i in g.node.keys():
            G.node[i]['state'] = SPREADING_SUSCEPTIBLE
            G.node[i]['color']='red'
        return G

    def spreading_seed2( g, infctd_prtn ):
        """Inject a random proportion of nodes in the graph."""
        for i in g.node.keys():
            if(i == infctd_prtn):
                G.node[i]['state'] = SPREADING_INFECTED
                G.node[i]['color']='green'
        return G
        
            
    def spreading_make_sis_model2( pInfect, pRecover ):
        """Return an SIR model function for given infection and recovery probabilities."""
        # model (local rule) function
        
        def model( g, i):
            if g.node[i]['state'] == SPREADING_INFECTED:
                # infect susceptible neighbours with probability pInfect
                for m in g.neighbors(i):
                    m=m.strip('\n')
                    if g.node[m]['state'] == SPREADING_SUSCEPTIBLE:
                        #if rnd.uniform(pInfect-0.05,pInfect+0.05) <= pInfect:
                        if rnd.uniform(pInfect-0.05,pInfect+0.05)  <= pInfect:
                            g.node[m]['state'] = SPREADING_INFECTED
                            g.node[m]['color'] = 'blue'
                    '''for m1 in g.neighbors(m):
                        m1=m1.strip('\n')
                        if g.node[m1]['state'] == SPREADING_SUSCEPTIBLE:
                            #if rnd.uniform(pInfect-0.05,pInfect+0.05) <= pInfect:
                            if rnd.random() <= pInfect:
                                g.node[m1]['state'] = SPREADING_INFECTED
                                g.node[m1]['color'] = 'blue'
                    if rnd.uniform(pRecover-0.05,pRecover+0.05) <= pRecover:
                        g.node[m]['state'] = SPREADING_SUSCEPTIBLE
                        g.node[m]['color'] = 'red'''
             
                # recover with probability pRecover
                #if rnd.uniform(pRecover-0.05,pRecover+0.05)  <= pRecover:
                if rnd.uniform(pRecover-0.05,pRecover+0.05)  <= pRecover:
                    g.node[i]['state'] = SPREADING_SUSCEPTIBLE
                    g.node[i]['color'] = 'red'
                  
        return model

    def spreading_step( g, model ):
        """Run a single step of the model over the graph."""
        for i in g.node.keys():
            model(g, i)
        
    def spreading_run2( g, model, itera ):
        """Run a number of iterations of the model over the graph."""
        for i in range(itera):
            spreading_step(g, model)

    # initialise with 5% sick people
    G1=spreading_init2(G)
    G=spreading_seed2(G1, infctd_prtn)

    # SIR model with 30% infection rate and 10% recovery rate
    model=spreading_make_sis_model2(pInfect, pRecover)


    # run SIR model dynamics over the network
    spreading_run2(G, model, itera)
    
    
    #infected1 = [ v for (v, attr) in G.nodes(data = True) if attr['state'] == SPREADING_INFECTED ]
    susceptible1= [ v for (v, attr) in G.nodes(data = True) if attr['state'] == SPREADING_SUSCEPTIBLE and ( v in G.neighbors(infctd_prtn) or v==infctd_prtn) ]
    #n=k
    print(str(susceptible1))
    print(str(k))
    return float(len(susceptible1)) / float(k)

edges=[]
nodes=[]
count=0
with open('cov_cov_interactions.txt', 'r') as in_file:
    stripped = (line.strip() for line in in_file)
    for line in stripped:
        line1=line.split("\t")
        count=count+1
        if count!=1:
            nodes.append(line1[0])
            nodes.append(line1[1])
            edges.append((line1[0],line1[1])) 
            
up_nodes=list(set(nodes))
up_edges=list(set(edges))

        
#print(up_nodes)
#print(up_edges)

#k=len(up_nodes)

#fgr1=open('spreadability_index_SIR.txt','w')
fgr2=open('spreadability_index_SIS.txt','w')



for nd in up_nodes:
    print(nd)
    hld1=0.0
    hld2=0.0
    '''
    for i in range(0,50):
        r1=SIR(G,k,nd,0.251, 0.01,100)
        hld1+=r1
        r2=SIS(G,k,nd,0.251, 0.01,100)
        hld2+=r2
    hld1_up=hld1/50
    hld2_up=hld2/50'''

    G=nx.Graph()
    #G1=nx.Graph()

    # add nodes and edges (color can be html color name or hex code)
    
    G.add_node(nd)

    G.add_edges_from(up_edges)
    
    
    #print(list(G.neighbors(nd)))
    #print('in')
    #r1=SIR(G,k,nd,0.228, 0.01,100)
    d=list(G.neighbors(nd))
    k=len(d)+1
    r2=SIS(G,k,nd,0.228, 0.01,50)
    #fgr1.writelines(nd+'|'+str(r1)+'\n')
    fgr2.writelines(nd+'|'+str(r2)+'\n')

    
#fgr1.close()
fgr2.close()

#fgr1_opn=open('spreadability_index_SIR.txt','r')
#hv1=fgr1_opn.readlines()
fgr2_opn=open('spreadability_index_SIS.txt','r')
hv2=fgr2_opn.readlines()

ga2=open('spreadability_index_SIS_desc_order.txt','w')

d2 = {}
for i1 in hv2:
    i1=i1.strip('\t')
    ji1=i1.split('|')
    keys = ji1[0]
    values = float(ji1[1])
    d2[keys] = values
    
sorted_d2 = OrderedDict(dict( sorted(d2.items(), key=operator.itemgetter(1),reverse=True)))

for nm2, vl2 in sorted_d2.items(): 
    ga2.writelines(nm2+"|"+str(vl2)+'\n') 
    
ga2.close()



