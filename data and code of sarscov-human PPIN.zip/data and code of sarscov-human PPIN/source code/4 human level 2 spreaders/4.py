# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 09:14:24 2020

@author: COD
"""
import operator
from collections import OrderedDict 

nodes=[]

fd12=open('only_humn_cnctd_prtn_list_for_cov1.txt','r')
on_nodes=fd12.readlines()


for ljh in on_nodes:
    ljh=ljh.strip('\t')
    ljh=ljh.strip()
    nodes.append(ljh)
    
up_nodes=list(set(nodes))


f7=open('nghbrhd_density.txt','r')
fds=f7.readlines()
f8=open('edge_ratio.txt','r')
ghf=f8.readlines()
fff5=open('node_weight.txt','r')
tvc=fff5.readlines()

f9=open('ultmt_score.txt','w')
fs=open('ultmt_score_inclng_node_weight.txt','w')

for t1 in up_nodes:
    t1=t1.strip('\n')
    #score1=0.0
    #score2=0.0
    #score3=0.0
    for bl in ghf:
        bl=bl.strip('\n')
        bk=bl.split('|')
        if t1 == bk[0]:
            score1=float(bk[1])
            break
    for po in fds:
        po=po.strip('\n')
        re=po.split('|')
        if t1 == re[0]:
            score2=float(re[1])
            break
        
    #print('yyyyy|'+t1+'|'+str(score1)+'|'+str(score2)+'|'+str(score1*score2))
    score=round(score1*score2,2)
    
    f9.writelines(t1+'|'+str(score)+'\n')
    
    for po1 in tvc:
        po1=po1.strip('\n')
        re1=po1.split('|')
        if t1 == re1[0]:
            score3=float(re1[1])
            break
        
    ult_score=(score1*score2)+score3
    
    fs.writelines(t1+'|'+str(ult_score)+'\n')
            
f9.close() 
fs.close()

de=open('ultmt_score.txt','r')
tn=de.readlines()

ga=open('ultmt_score_desc_order.txt','w')

d = {}
for i in tn:
    i=i.strip('\n')
    ji=i.split('|')
    keys = ji[0]
    values = float(ji[1])
    d[keys] = values
    
sorted_d = OrderedDict(sorted(d.items(), key=operator.itemgetter(1),reverse=True))

for nm, vl in sorted_d.items(): 
    ga.writelines(nm+"|"+str(vl)+'\n') 
    
ga.close()


de1=open('ultmt_score_inclng_node_weight.txt','r')
tn1=de1.readlines()

ga1=open('ultmt_score_inclng_node_weight_desc_order.txt','w')

d1 = {}
for i1 in tn1:
    i1=i1.strip('\n')
    ji1=i1.split('|')
    keys = ji1[0]
    values = float(ji1[1])
    d1[keys] = values
    
sorted_d1 = OrderedDict( sorted(d1.items(), key=operator.itemgetter(1),reverse=True))

for nm1, vl1 in sorted_d1.items(): 
    ga1.writelines(nm1+"|"+str(vl1)+'\n') 
    
ga1.close()