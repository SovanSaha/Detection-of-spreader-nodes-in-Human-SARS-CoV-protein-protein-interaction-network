# -*- coding: utf-8 -*-
"""
Created on Sat Jan 25 14:14:03 2020

@author: CSE9
"""
import operator
from collections import OrderedDict 
from itertools import combinations

edges=[]
nodes=[]
count=0
edges1=[]

fd12=open('only_humn_cnctd_prtn_list_for_cov1.txt','r')
on_nodes=fd12.readlines()

f1=open('edge_ratio.txt','w')
f2=open('node_com_level1_level2.txt','w')
ff3=open('node_weight.txt','w')
with open('level1-level2-full_ref2.txt', 'r') as in_file:
    stripped = (line.strip() for line in in_file)
    for line in stripped:
        line1=line.split()
        #print(line1)
        count=count+1
        if count!=1:
            #nodes.append(line1[0])
            #nodes.append(line1[1])
            edges.append((line1[0],line1[1])) 
            edges1.append((line1[0]+','+line1[1])) 
        
#up_nodes=list(set(nodes))
up_edges=list(set(edges))
up_edges1=list(set(edges1))

for ljh in on_nodes:
    ljh=ljh.strip('\t')
    ljh=ljh.strip()
    nodes.append(ljh)
    
up_nodes=list(set(nodes))

d = {}
for i in up_nodes:
    keys = i
    values = '#FFA500'
    d[keys] = values
    
#print(d)

keys=[]
color_map=[]
for key in d:
    keys.append(key)
    color_map.append(d[key])
    
#print(keys)
#print(color_map)


import networkx as nx
G=nx.Graph()

# add nodes and edges (color can be html color name or hex code)
for key in d:
    G.add_node(str(key),color=str(d[key]))

G.add_edges_from(up_edges)


def jcrd(a,b):
    
    neighbors_a=[]
    neighbors_b=[]
    
    for line in up_edges1:
        line=line.strip('\n')
        if a in line:
            hld=line.split(',')
            if a==hld[0]:
                neighbors_a.append(hld[1])
            if a==hld[1]:
                neighbors_a.append(hld[0])
        if b in line:
            hld=line.split(',')
            if b==hld[0]:
                neighbors_b.append(hld[1])
            if b==hld[1]:
                neighbors_b.append(hld[0])       
    
    neighbors_a=list(set(neighbors_a))
    neighbors_b=list(set(neighbors_b))
    
    nmrtr=len((set(neighbors_a).intersection(set(neighbors_b))))
    
    dnmntr=len((set(neighbors_a).union(set(neighbors_b))))
    
    sim=float(nmrtr/dnmntr)
    
    #print('sim')
    #print(sim)
    
    result=1-sim

    return result   

#print(list(G.degree(up_nodes)))

#print (up_edges)
#print (up_edges1)


for nd in up_nodes:
    level1_nghbr=[]
    level2_nghbr=[]
    level1=[]
    level2=[]
    nd=nd.strip('\n')
    for line in up_edges1:
        line=line.strip('\n')
        if nd in line:
            hld=line.split(',')
            if nd==hld[0]:
                level1_nghbr.append(hld[1])
                level1.append(hld[1])
            if nd==hld[1]:
                level1_nghbr.append(hld[0])
                level1.append(hld[0])
    level1_nghbr=list(set(level1_nghbr))
    level1=list(set(level1))
    
    degrees1 = [val for (node, val) in G.degree(level1_nghbr)]
    
    #degrees1a = [node for (node, val) in G.degree(level1_nghbr)]
    
    #print('pnt')
    #print(degrees1)
    #print(degrees1a)
    
    l=len(level1_nghbr)+1
    
    
    #print(nd+'|'+str(sum(degrees1))+'|'+str(l))
    
    res=sum(degrees1)/l
    
    
    ff3.writelines(nd+'|'+str(res)+'\n')
    
    #print(level1)
    #print(level1_nghbr)
    #count1=0
    inbtwn=[]
    #print(level1_nghbr)
    for ln in level1_nghbr:
        ln=ln.strip('\n')
        for line in up_edges1:
            line=line.strip('\n')
            if ln in line:
                hld=line.split(',')
                if ln==hld[0]:
                    if hld[1] in level1_nghbr:
                        #count1=count1+1
                        inbtwn.append(line)
                    if hld[1] not in level1_nghbr and  hld[1] != nd:
                        level2_nghbr.append(hld[0]+','+hld[1])
                if ln==hld[1]:
                    if hld[0] in level1_nghbr:
                        inbtwn.append(line)
                    if hld[0] not in level1_nghbr and hld[0]!= nd:
                        level2_nghbr.append(hld[0]+','+hld[1])
    #print(inbtwn)
    count1=len(list(set(inbtwn)))
  
    #print(level2_nghbr)
    count2=len(list(set(level2_nghbr)))
   
    #print(count2)
    com=(count2+1)/(count1+1)
    #print(com)
    #print(nd+'|'+str(com))
    f1.write(nd+'|'+str(com)+'\n')
    
    for i in level1:
        i=i.strip('\n')
        for line in up_edges1:
            line=line.strip('\n')
            if i in line:
                hld=line.split(',')
                if i==hld[0]:
                    s=''
                    s+=hld[1]
                    level2.append(s)
                else:
                    s=''
                    s+=hld[0]
                    level2.append(s)
    
    #print(nd)
    #print(level2)
    level2=list(set(level2))
    b=[]
    b.append(nd)
    #print(b)
    level2=list(set(level2)-set(b))
    #print(level2)
    #print(level1)
    com=list(set(level1).union(set(level2)))
    #print(com)
    f2.write(nd+'|'+','.join(com)+'\n')
    
f1.close()
f2.close()
ff3.close()

'''f3=open('node_com_level1_level2.txt','r')
hf=f3.readlines()'''

'''f4=open('edges_jcrd_dismlrty_scr.txt','w')

#change this part
print(len(up_edges1))
for lnn in up_edges1:
    print('ege::::::::'+'|'+lnn)
    lnn=lnn.strip('\t')
    hb=lnn.split(',')
    for bv in hf:
        bv=bv.strip('\t')
        if bv.startswith(hb[0]):
            fd1=bv.split('|')
            first=fd1[1].split(',')
        if bv.startswith(hb[1]):
            fd2=bv.split('|')
            second=fd2[1].split(',')
    compt=1-(len(list(set(first).intersection(set(second))))/len(list(set(first).union(set(second)))))
    f4.writelines(lnn+'|'+str(jcrd(hb[0],hb[1]))+'\n')

f4.close()

f5=open('edges_jcrd_dismlrty_scr.txt','r')
stre=f5.readlines()'''

