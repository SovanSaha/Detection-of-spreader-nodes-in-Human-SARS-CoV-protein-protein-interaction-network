1: First create a file containing only level 2 human proteins of sarscov which will be the input of 1.py.
2: Run 1.py
3: Run 2.py 
5: Run 3.py
6: Run 4.py
7: Run 5.py
8: Run 6.py


Note: 

Modify names of the text files inside python files accordingly.

For comparison of spreadability index with other centrality measures like BC, CC, LAC and DC use cytoscape.  