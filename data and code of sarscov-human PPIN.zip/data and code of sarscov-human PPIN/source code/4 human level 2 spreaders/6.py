# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 13:52:11 2019

@author: CSE9
"""

import numpy.random as rnd
from collections import OrderedDict 
import operator
import networkx as nx
import threading 

count=0
edges=[]

fgr2=open('spreadability_index_SIS.txt','w')

with open('level1-level2-full_ref2.txt', 'r') as in_file:
    stripped = (line.strip() for line in in_file)
    for line in stripped:
        line1=line.split()
        count=count+1
        if count!=1:
            edges.append((line1[0],line1[1])) 

up_edges=list(set(edges))

def divide(lst, n):
    p = len(lst) // n
    if len(lst)-p > 0:
        return [lst[:p]] + divide(lst[p:], n-1)
    else:
        return [lst]
    

    
def SIS(G,k,infctd_prtn,pInfect, pRecover,itera):
    
    SPREADING_SUSCEPTIBLE = 'S'
    SPREADING_INFECTED = 'I'
    #SPREADING_INFECTED_SUSCEPTIBLE = 'IS'


    def spreading_init2( g ):
        """Initialise all node in the graph to be susceptible."""
        for i in g.node.keys():
            G.node[i]['state'] = SPREADING_SUSCEPTIBLE
            G.node[i]['color']='red'
        return G

    def spreading_seed2( g, infctd_prtn ):
        """Inject a random proportion of nodes in the graph."""
        for i in g.node.keys():
            if(i == infctd_prtn):
                G.node[i]['state'] = SPREADING_INFECTED
                G.node[i]['color']='green'
        return G
        
            
    def spreading_make_sis_model2( pInfect, pRecover ):
        """Return an SIR model function for given infection and recovery probabilities."""
        # model (local rule) function
        
        def model( g, i):
            if g.node[i]['state'] == SPREADING_INFECTED:
                # infect susceptible neighbours with probability pInfect
                for m in g.neighbors(i):
                    m=m.strip('\n')
                    if g.node[m]['state'] == SPREADING_SUSCEPTIBLE:
                        #if rnd.uniform(pInfect-0.05,pInfect+0.05) <= pInfect:
                        if rnd.uniform(pInfect-0.05,pInfect+0.05)  <= pInfect:
                            g.node[m]['state'] = SPREADING_INFECTED
                            g.node[m]['color'] = 'blue'
                    '''for m1 in g.neighbors(m):
                        m1=m1.strip('\n')
                        if g.node[m1]['state'] == SPREADING_SUSCEPTIBLE:
                            #if rnd.uniform(pInfect-0.05,pInfect+0.05) <= pInfect:
                            if rnd.random() <= pInfect:
                                g.node[m1]['state'] = SPREADING_INFECTED
                                g.node[m1]['color'] = 'blue'
                    if rnd.uniform(pRecover-0.05,pRecover+0.05) <= pRecover:
                        g.node[m]['state'] = SPREADING_SUSCEPTIBLE
                        g.node[m]['color'] = 'red'''
             
                # recover with probability pRecover
                #if rnd.uniform(pRecover-0.05,pRecover+0.05)  <= pRecover:
                if rnd.uniform(pRecover-0.05,pRecover+0.05)  <= pRecover:
                    g.node[i]['state'] = SPREADING_SUSCEPTIBLE
                    g.node[i]['color'] = 'red'
                  
        return model

    def spreading_step( g, model ):
        """Run a single step of the model over the graph."""
        for i in g.node.keys():
            model(g, i)
        
    def spreading_run2( g, model, itera ):
        """Run a number of iterations of the model over the graph."""
        for i in range(itera):
            spreading_step(g, model)

    # initialise with 5% sick people
    G1=spreading_init2(G)
    G=spreading_seed2(G1, infctd_prtn)

    # SIR model with 30% infection rate and 10% recovery rate
    model=spreading_make_sis_model2(pInfect, pRecover)


    # run SIR model dynamics over the network
    spreading_run2(G, model, itera)
    
    
    #infected1 = [ v for (v, attr) in G.nodes(data = True) if attr['state'] == SPREADING_INFECTED ]
    susceptible1= [ v for (v, attr) in G.nodes(data = True) if attr['state'] == SPREADING_SUSCEPTIBLE and ( v in G.neighbors(infctd_prtn) or v==infctd_prtn) ]
    #n=k
    #print(str(susceptible1))
    #print(str(k))
    return float(len(susceptible1)) / float(k)


def com1(part1): 
    a1=[]
    q=len(part1)
    for t in part1:
        t=t.strip('\n')
        print('thread1'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end1')
        a1.append(t)
        print('rem thread1:'+str(q-len(a1)))
      
    
def com2(part2): 
    a2=[]
    q=len(part2)
    for t in part2:
        t=t.strip('\n')
        print('thread2'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end2')
        a2.append(t)
        print('rem thread2:'+str(q-len(a2)))
    
def com3(part3): 
    a3=[]
    q=len(part3)
    for t in part3:
        t=t.strip('\n')
        print('thread3'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end3')
        a3.append(t)
        print('rem thread3:'+str(q-len(a3)))
    
def com4(part4): 
    a4=[]
    q=len(part4)
    for t in part4:
        t=t.strip('\n')
        print('thread4'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end4')
        a4.append(t)
        print('rem thread4:'+str(q-len(a4)))
        
def com5(part5): 
    a5=[]
    q=len(part5)
    for t in part5:
        t=t.strip('\n')
        print('thread5'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end5')
        a5.append(t)
        print('rem thread5:'+str(q-len(a5)))

def com6(part6):
    a6=[]
    q=len(part6)
    for t in part6:
        t=t.strip('\n')
        print('thread6'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end6')
        a6.append(t)
        print('rem thread6:'+str(q-len(a6)))
        
def com7(part7):
    a7=[]
    q=len(part7)
    for t in part7:
        t=t.strip('\n')
        print('thread7'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end7')
        a7.append(t)
        print('rem thread7:'+str(q-len(a7)))
        
def com8(part8):
    a8=[]
    q=len(part8)
    for t in part8:
        t=t.strip('\n')
        print('thread8'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end8')
        a8.append(t)
        print('rem thread8:'+str(q-len(a8)))
        
def com9(part9):
    a9=[]
    q=len(part9)
    for t in part9:
        t=t.strip('\n')
        print('thread9'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end9')
        a9.append(t)
        print('rem thread9:'+str(q-len(a9)))
        
def com10(part10):
    a10=[]
    q=len(part10)
    for t in part10:
        t=t.strip('\n')
        print('thread10'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end10')
        a10.append(t)
        print('rem thread10:'+str(q-len(a10)))
       
def com11(part11):
    a11=[]
    q=len(part11)
    for t in part11:
        t=t.strip('\n')
        print('thread11'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end11')
        a11.append(t)
        print('rem thread11:'+str(q-len(a11)))
       
        
def com12(part12):
    a12=[]
    q=len(part12)
    for t in part12:
        t=t.strip('\n')
        print('thread12'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end12')
        a12.append(t)
        print('rem thread12:'+str(q-len(a12)))
            
        
def com13(part13):
    a13=[]
    q=len(part13)
    for t in part13:
        t=t.strip('\n')
        print('thread13'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end13')
        a13.append(t)
        print('rem thread13:'+str(q-len(a13)))
        
        
def com14(part14):
    a14=[]
    q=len(part14)
    for t in part14:
        t=t.strip('\n')
        print('thread14'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end14')
        a14.append(t)
        print('rem thread14:'+str(q-len(a14)))
     
        
def com15(part15):
    a15=[]
    q=len(part15)
    for t in part15:
        t=t.strip('\n')
        print('thread15'+t)
        G=nx.Graph()  
        G.add_node(t)
        G.add_edges_from(up_edges)
        d=list(G.neighbors(t))
        k=len(d)+1
        r2=SIS(G,k,t,0.0045, 0.01,10)
        #fgr1.writelines(nd+'|'+str(r1)+'\n')
        fgr2.writelines(t+'|'+str(r2)+'\n')
        print('end15')
        a15.append(t)
        print('rem thread15:'+str(q-len(a15)))
      
        
def main(): 
    
    str1=[]
    
    f1=open('only_humn_cnctd_prtn_list_for_cov1.txt','r')

    hld1=f1.readlines()

    str1=[]

    for line1 in hld1:
        line1=line1.strip('\n')
        str1.append(line1)
        
    hmn=list(set(str1))

                
    hmn=list(set(hmn))
    #print(hmn)
            
    up_nodes=hmn
    
    up_nodes1=list(set(up_nodes))
    q=divide(up_nodes1,15)
    part11=q[0]
    part22=q[1]
    part33=q[2]
    part44=q[3]
    part55=q[4]
    part66=q[5]
    part77=q[6]
    part88=q[7]
    part99=q[8]
    part100=q[9]
    part111=q[10]
    part112=q[11]
    part113=q[12]
    part114=q[13]
    part115=q[14]

    
    t1 = threading.Thread(target=com1, args=(part11,)) 
    t2 = threading.Thread(target=com2, args=(part22,)) 
    t3 = threading.Thread(target=com3, args=(part33,)) 
    t4 = threading.Thread(target=com4, args=(part44,)) 
    t5 = threading.Thread(target=com5, args=(part55,)) 
    t6 = threading.Thread(target=com6, args=(part66,))
    t7 = threading.Thread(target=com7, args=(part77,)) 
    t8 = threading.Thread(target=com8, args=(part88,)) 
    t9 = threading.Thread(target=com9, args=(part99,)) 
    t10 = threading.Thread(target=com10, args=(part100,))
    t11 = threading.Thread(target=com11, args=(part111,)) 
    t12 = threading.Thread(target=com12, args=(part112,)) 
    t13 = threading.Thread(target=com13, args=(part113,)) 
    t14 = threading.Thread(target=com14, args=(part114,)) 
    t15 = threading.Thread(target=com15, args=(part115,)) 
  
 
    t1.start() 
    t2.start() 
    t3.start()
    t4.start()
    t5.start()
    t6.start()
    t7.start()
    t8.start()
    t9.start()
    t10.start()
    t11.start()
    t12.start()
    t13.start()
    t14.start()
    t15.start()
   
    t1.join() 
    t2.join() 
    t3.join()
    t4.join()
    t5.join()
    t6.join()
    t7.join()
    t8.join()
    t9.join()
    t10.join()
    t11.join()
    t12.join()
    t13.join()
    t14.join()
    t15.join()
    
    fgr2.close()
  
    # both threads completely executed 
    print("Done!") 
    
    #fgr1_opn=open('spreadability_index_SIR.txt','r')
    #hv1=fgr1_opn.readlines()
    fgr2_opn=open('spreadability_index_SIS.txt','r')
    hv2=fgr2_opn.readlines()

    ga2=open('spreadability_index_SIS_desc_order.txt','w')

    d2 = {}
    for i1 in hv2:
        i1=i1.strip('\t')
        ji1=i1.split('|')
        keys = ji1[0]
        values = float(ji1[1])
        d2[keys] = values
    
    sorted_d2 = OrderedDict(( sorted(d2.items(), key=operator.itemgetter(1),reverse=True)))

    for nm2, vl2 in sorted_d2.items(): 
        ga2.writelines(nm2+"|"+str(vl2)+'\n') 
    
    ga2.close()


main()


