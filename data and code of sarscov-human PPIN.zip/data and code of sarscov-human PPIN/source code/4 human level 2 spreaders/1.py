# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

f1=open('only_humn_cnctd_prtn_list_for_cov.txt','r')
hld1=f1.readlines()

f2=open('human_human_interactions.txt','r')
hld2=f2.readlines()

f3=open('only_humn_cnctd_prtn_list_for_cov1.txt','w')

count2=0

list_prtn=[]

for line1 in hld1:
    line1=line1.strip('\n')
    for line2 in hld2:
        line2=line2.strip('\n')
        count2=count2+1
        if(count2!=1):
            if line1 in line2:
                str1=line2.split()
                s1=str1[0].strip()
                s2=str1[1].strip()
                if line1==s1:
                    list_prtn.append(s2)
                if line1==s2:
                    list_prtn.append(s1)

list_prtn=list(set(list_prtn))

for ln in list_prtn:
    ln=ln.strip('\n')
    f3.writelines(ln+'\n')
    
f3.close()

list_prtn_l1=[]

list_prtn_edges_l1=[]

for t in list_prtn:
    t=t.strip('\n')
    for line2 in hld2:
        line2=line2.strip('\n')
        count2=count2+1
        if(count2!=1):
            if t in line2:
                str1=line2.split()
                s1=str1[0].strip()
                s2=str1[1].strip()
                if t==s1:
                    list_prtn_l1.append(s2)
                    list_prtn_edges_l1.append(line2)
                if t==s2:
                    list_prtn_l1.append(s1)
                    list_prtn_edges_l1.append(line2)
                    
list_prtn_l1=list(set(list_prtn_l1))
list_prtn_edges_l1=list(set(list_prtn_edges_l1))

fv=open('level1.txt','w')
fb=open('level1-level2-full.txt','w')

for linee in list_prtn_edges_l1:
    linee=linee.strip('\n')
    fv.writelines(linee+'\n')
    fb.writelines(linee+'\n')
    
fv.close()



for t in list_prtn_l1:
    t=t.strip('\n')
    for line2 in hld2:
        line2=line2.strip('\n')
        count2=count2+1
        if(count2!=1):
            if t in line2:
                str1=line2.split()
                s1=str1[0].strip()
                s2=str1[1].strip()
                if t==s1:
                    fb.writelines(line2+'\n')
                if t==s2:
                    fb.writelines(line2+'\n')

fb.close()

f10=open('level1-level2-full.txt','r')
fcx=f10.readlines()

gs=[]

for ln in fcx:
    ln=ln.strip('\n')
    gs.append(ln)
    
gs=list(set(gs))

f11=open('level1-level2-full_ref1.txt','w')

for t in gs:
    t=t.strip('\n')
    f11.writelines(t+'\n')
    
f11.close()


f12=open('level1-level2-full_ref1.txt','r')
gv=f12.readlines()
f13=open('level1-level2-full_ref2.txt','w')
k=[]
for t in gv:
    t=t.strip('\n')
    r=t.split()
    if(r[0]>r[1]):
        k.append(r[0]+'\t'+r[1])
    if(r[1]>r[0]):
        k.append(r[1]+'\t'+r[0])

k=list(set(k))
        
for y in k:
    y=y.strip('\t')
    f13.writelines(y+'\n')
    
f13.close()
    
    



























                        
            
            