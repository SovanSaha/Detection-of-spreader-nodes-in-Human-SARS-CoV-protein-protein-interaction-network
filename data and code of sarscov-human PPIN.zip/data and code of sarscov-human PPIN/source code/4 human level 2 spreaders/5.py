# -*- coding: utf-8 -*-
"""
Created on Mon Mar 30 17:30:01 2020

@author: COD
"""
import statistics
import math

file_input1 = open('final_ranking_cov_human_edges.txt', 'r')
edge_rnkngs = file_input1.readlines()

file_output1 = open('L2_thresholds.txt', 'w')

edge_rank = []

for line in edge_rnkngs:
    line=line.strip('\n')
    store = line.split('|')
    edge_rank.append(float(store[2]))

arthmtc_mean = statistics.mean(edge_rank)

stndrd_dev = statistics.stdev(edge_rank)

# k=1
low_thrshld = arthmtc_mean + (1 * stndrd_dev * (1 - (1 / (1 + math.pow(stndrd_dev, 2)))))

file_output1.write('low threshold' + '|' + str(low_thrshld) + '\n')

# k=2
medium_thrshld = arthmtc_mean + (2 * stndrd_dev * (1 - (1 / (1 + math.pow(stndrd_dev, 2)))))

file_output1.write('medium threshold' + '|' + str(medium_thrshld) + '\n')

# k=3
high_thrshld = arthmtc_mean + (3 * stndrd_dev * (1 - (1 / (1 + math.pow(stndrd_dev, 2)))))

file_output1.write('high threshold' + "|" + str(high_thrshld) + '\n')

file_output1.close()


file_output2 = open('L2_low_threshold_rnkd_edges.txt', 'w')
file_output3 = open('L2_medium_threshold_rnkd_edges.txt', 'w')
file_output4 = open('L2_high_threshold_rnkd_edges.txt', 'w')

for line in edge_rnkngs:
    line=line.strip('\n')
    store = line.split('|')
    if (float(store[2])>low_thrshld):
        file_output2.writelines(line+'\n')
    if (float(store[2])>medium_thrshld ):
        file_output3.writelines(line+'\n')
    if (float(store[2])>high_thrshld):
        file_output4.writelines(line+'\n')
        
        
file_output2.close()
file_output3.close()
file_output4.close()







