# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 16:37:31 2020

@author: sovan-PC
"""

import threading 
from itertools import combinations
#import operator
#from collections import OrderedDict 
#from itertools import combinations

f6=open('nghbrhd_density.txt','w')

fc1=open('lvl1.txt','r')
tv1=fc1.readlines()


d = {}

for g in tv1:
    g=g.strip()
    hlf=g.split('\t')
    keys=hlf[0].strip()
    d[keys] = hlf[1].strip()
    

def divide(lst, n):
    p = len(lst) // n
    if len(lst)-p > 0:
        return [lst[:p]] + divide(lst[p:], n-1)
    else:
        return [lst]
    
def jcrd(a,b):
    
    a=a.strip()
    b=b.strip()
    neighbors_a=[]
    neighbors_b=[]
    
    if a in d.keys(): 
        h=d[a].split(',')
        for r in h:
            r=r.strip()
            neighbors_a.append(r)
            
    if b in d.keys(): 
        h=d[b].split(',')
        for r in h:
            r=r.strip()
            neighbors_b.append(r)
    
    
    '''for line in tv1:
        line=line.strip('\n')
        if line.startswith (a):
            hld1=line.split('\t')
            if a==hld1[0]:
                flag1=1
                s=(hld1[1].split(','))
                for t in s:
                    t=t.strip('\n')
                    neighbors_a.append(t)
                    
                
        if line.startswith (b):
            hld2=line.split('\t')
            if b==hld2[0]:
                flag2=1
                d=(hld2[1].split(','))
                for t in d:
                    t=t.strip('\n')
                    neighbors_b.append(t)
                    
        if flag1==1 and flag2==1:
            break'''
    
    neighbors_a=list(set(neighbors_a))
    neighbors_b=list(set(neighbors_b))
    
    #print(neighbors_a)
    #print(neighbors_b)
    
    nmrtr=len((set(neighbors_a).intersection(set(neighbors_b))))
    
    dnmntr=len((set(neighbors_a).union(set(neighbors_b))))
    
    sim=float(nmrtr/dnmntr)
    
    #print('sim')
    #print(sim)
    
    result=1-sim

    return result 

def com1(part1): 
    a1=[]
    q=len(part1)
    for t in part1:
        t=t.strip('\n')
        print('thread1'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
            
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end1')
        a1.append(t)
        print('rem thread1:'+str(q-len(a1)))
        f6.writelines(t+'|'+str(total)+'\n')
    
def com2(part2): 
    a2=[]
    q=len(part2)
    for t in part2:
        t=t.strip('\n')
        print('thread2'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end2')
        a2.append(t)
        print('rem thread2:'+str(q-len(a2)))
        f6.writelines(t+'|'+str(total)+'\n')  
    
def com3(part3): 
    a3=[]
    q=len(part3)
    for t in part3:
        t=t.strip('\n')
        print('thread3'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end3')
        a3.append(t)
        print('rem thread3:'+str(q-len(a3)))
        f6.writelines(t+'|'+str(total)+'\n')
    
    
def com4(part4): 
    a4=[]
    q=len(part4)
    for t in part4:
        t=t.strip('\n')
        print('thread4'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end4')
        a4.append(t)
        print('rem thread4:'+str(q-len(a4)))
        f6.writelines(t+'|'+str(total)+'\n')
        
def com5(part5): 
    a5=[]
    q=len(part5)
    for t in part5:
        t=t.strip('\n')
        print('thread5'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end5')
        a5.append(t)
        print('rem thread5:'+str(q-len(a5)))
        f6.writelines(t+'|'+str(total)+'\n')

def com6(part6):
    a6=[]
    q=len(part6)
    for t in part6:
        t=t.strip('\n')
        print('thread6'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end6')
        a6.append(t)
        print('rem thread6:'+str(q-len(a6)))
        f6.writelines(t+'|'+str(total)+'\n')
        
def com7(part7):
    a7=[]
    q=len(part7)
    for t in part7:
        t=t.strip('\n')
        print('thread7'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end7')
        a7.append(t)
        print('rem thread7:'+str(q-len(a7)))
        f6.writelines(t+'|'+str(total)+'\n')
        
def com8(part8):
    a8=[]
    q=len(part8)
    for t in part8:
        t=t.strip('\n')
        print('thread8'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end8')
        a8.append(t)
        print('rem thread8:'+str(q-len(a8)))
        f6.writelines(t+'|'+str(total)+'\n')
        
def com9(part9):
    a9=[]
    q=len(part9)
    for t in part9:
        t=t.strip('\n')
        print('thread9'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end9')
        a9.append(t)
        print('rem thread9:'+str(q-len(a9)))
        f6.writelines(t+'|'+str(total)+'\n')
        
def com10(part10):
    a10=[]
    q=len(part10)
    for t in part10:
        t=t.strip('\n')
        print('thread10'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end10')
        a10.append(t)
        print('rem thread10:'+str(q-len(a10)))
        f6.writelines(t+'|'+str(total)+'\n')       
        
def com11(part11):
    a11=[]
    q=len(part11)
    for t in part11:
        t=t.strip('\n')
        print('thread11'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end11')
        a11.append(t)
        print('rem thread11:'+str(q-len(a11)))
        f6.writelines(t+'|'+str(total)+'\n')
        
def com12(part12):
    a12=[]
    q=len(part12)
    for t in part12:
        t=t.strip('\n')
        print('thread12'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end12')
        a12.append(t)
        print('rem thread12:'+str(q-len(a12)))
        f6.writelines(t+'|'+str(total)+'\n')       
        
def com13(part13):
    a13=[]
    q=len(part13)
    for t in part13:
        t=t.strip('\n')
        print('thread13'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end13')
        a13.append(t)
        print('rem thread13:'+str(q-len(a13)))
        f6.writelines(t+'|'+str(total)+'\n')     
        
def com14(part14):
    a14=[]
    q=len(part14)
    for t in part14:
        t=t.strip('\n')
        print('thread14'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end14')
        a14.append(t)
        print('rem thread14:'+str(q-len(a14)))
        f6.writelines(t+'|'+str(total)+'\n')   
        
def com15(part15):
    a15=[]
    q=len(part15)
    for t in part15:
        t=t.strip('\n')
        print('thread15'+t)
        total=0.0
        if t in d.keys():
            level1_hld=d[t].split(',')
        '''for line in tv1:
            line=line.strip('\n')
            if line.startswith(t):
                hld=line.split('\t')
                if t==hld[0]:
                    level1_hld=(hld[1].split(','))
                    break'''
        level1_hld=list(set(level1_hld))
        comb=list(combinations(level1_hld,2))
        comb_chng=[','.join(l) for l in comb]
        for e in comb_chng:
            e=e.strip('\n')
            u=e.split(',')
            total+=float(jcrd(u[0],u[1]))
        print('end15')
        a15.append(t)
        print('rem thread15:'+str(q-len(a15)))
        f6.writelines(t+'|'+str(total)+'\n')   
        
        
def main(): 
    
    fd12=open('only_humn_cnctd_prtn_list_for_cov1.txt','r')
    on_nodes=fd12.readlines()
        
    up_nodes=list(set(on_nodes))
    q=divide(up_nodes,15)
    part11=q[0]
    part22=q[1]
    part33=q[2]
    part44=q[3]
    part55=q[4]
    part66=q[5]
    part77=q[6]
    part88=q[7]
    part99=q[8]
    part100=q[9]
    part111=q[10]
    part112=q[11]
    part113=q[12]
    part114=q[13]
    part115=q[14]

    
    t1 = threading.Thread(target=com1, args=(part11,)) 
    t2 = threading.Thread(target=com2, args=(part22,)) 
    t3 = threading.Thread(target=com3, args=(part33,)) 
    t4 = threading.Thread(target=com4, args=(part44,)) 
    t5 = threading.Thread(target=com5, args=(part55,)) 
    t6 = threading.Thread(target=com6, args=(part66,))
    t7 = threading.Thread(target=com7, args=(part77,)) 
    t8 = threading.Thread(target=com8, args=(part88,)) 
    t9 = threading.Thread(target=com9, args=(part99,)) 
    t10 = threading.Thread(target=com10, args=(part100,))
    t11 = threading.Thread(target=com11, args=(part111,)) 
    t12 = threading.Thread(target=com12, args=(part112,)) 
    t13 = threading.Thread(target=com13, args=(part113,)) 
    t14 = threading.Thread(target=com14, args=(part114,)) 
    t15 = threading.Thread(target=com15, args=(part115,)) 
  
 
    t1.start() 
    t2.start() 
    t3.start()
    t4.start()
    t5.start()
    t6.start()
    t7.start()
    t8.start()
    t9.start()
    t10.start()
    t11.start()
    t12.start()
    t13.start()
    t14.start()
    t15.start()
   
    t1.join() 
    t2.join() 
    t3.join()
    t4.join()
    t5.join()
    t6.join()
    t7.join()
    t8.join()
    t9.join()
    t10.join()
    t11.join()
    t12.join()
    t13.join()
    t14.join()
    t15.join()
    
    f6.close()
  
    # both threads completely executed 
    print("Done!") 
    
main()

    
    
    
    
    
    




